import setuptools

setuptools.setup(
    name="boopy",
    version="0.1",
    author="Xiar Fatah",
    author_email="xiar.fatah@gmail.com",
    url="https://github.com/Xiar-fatah/bootstrapy",
    packages=setuptools.find_packages(),
)
